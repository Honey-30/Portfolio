import { useEffect } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import SkillsSection from "@/components/skills-section";
import ProjectsSection from "@/components/projects-section";
import ExperienceSection from "@/components/experience-section";
import ContactSection from "@/components/contact-section";
import AnimatedCursor from "@/components/animated-cursor";
import BackgroundEffects from "@/components/background-effects";

export default function Portfolio() {
  useEffect(() => {
    document.title = "Honey Nandal - AI/ML Portfolio";
  }, []);

  return (
    <div className="relative min-h-screen">
      <AnimatedCursor />
      <BackgroundEffects />
      <Navigation />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ProjectsSection />
      <ExperienceSection />
      <ContactSection />
      
      {/* Footer */}
      <footer className="py-8 border-t border-electric-blue/20">
        <div className="container mx-auto px-6 text-center">
          <p className="text-gray-400">
            © 2024 Honey Nandal. Crafted with{" "}
            <span className="text-electric-blue">AI</span> and{" "}
            <span className="text-hot-pink">❤️</span>
          </p>
        </div>
      </footer>
    </div>
  );
}
