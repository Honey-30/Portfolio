import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { Code, Brain, Database } from "lucide-react";
import { SiPython, SiJavascript, SiReact, SiTensorflow, SiMysql } from "react-icons/si";

export default function SkillsSection() {
  const isVisible = useScrollAnimation("skills");

  const programmingSkills = [
    { name: "Python", percentage: 90 },
    { name: "Java", percentage: 85 },
    { name: "JavaScript", percentage: 80 },
  ];

  const aimlSkills = [
    { name: "Machine Learning", percentage: 88 },
    { name: "Deep Learning", percentage: 82 },
    { name: "NLP", percentage: 78 },
  ];

  const dataWebSkills = [
    { name: "Data Analysis", percentage: 85 },
    { name: "Web Development", percentage: 83 },
    { name: "MySQL", percentage: 80 },
  ];

  const tools = [
    { name: "Python", icon: SiPython, colors: ["hsl(195, 100%, 50%)", "hsl(270, 100%, 50%)"] },
    { name: "Java", icon: Code, colors: ["hsl(270, 100%, 50%)", "hsl(328, 100%, 54%)"] },
    { name: "JavaScript", icon: SiJavascript, colors: ["hsl(120, 100%, 50%)", "hsl(195, 100%, 50%)"] },
    { name: "MySQL", icon: SiMysql, colors: ["hsl(328, 100%, 54%)", "hsl(51, 100%, 50%)"] },
    { name: "Machine Learning", icon: Brain, colors: ["hsl(51, 100%, 50%)", "hsl(195, 100%, 50%)"] },
    { name: "React", icon: SiReact, colors: ["hsl(195, 100%, 50%)", "hsl(120, 100%, 50%)"] },
    { name: "TensorFlow", icon: SiTensorflow, colors: ["hsl(270, 100%, 50%)", "hsl(328, 100%, 54%)"] },
    { name: "Data Science", icon: Database, colors: ["hsl(120, 100%, 50%)", "hsl(51, 100%, 50%)"] },
  ];

  return (
    <section id="skills" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">
            Skills & Expertise
          </h2>
          
          {/* Technical Skills */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="skill-sphere glassmorphism p-6 rounded-3xl text-center professional-border">
              <Code size={48} className="mx-auto mb-4" style={{ color: 'hsl(210, 50%, 60%)' }} />
              <h3 className="text-xl font-semibold mb-4">Programming</h3>
              <div className="space-y-3">
                {programmingSkills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span>{skill.name}</span>
                      <span>{skill.percentage}%</span>
                    </div>
                    <div className="progress-bar h-2">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${skill.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="skill-sphere glassmorphism p-6 rounded-3xl text-center professional-border">
              <Brain size={48} className="mx-auto mb-4" style={{ color: 'hsl(220, 15%, 55%)' }} />
              <h3 className="text-xl font-semibold mb-4">AI/ML</h3>
              <div className="space-y-3">
                {aimlSkills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span>{skill.name}</span>
                      <span>{skill.percentage}%</span>
                    </div>
                    <div className="progress-bar h-2">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${skill.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="skill-sphere glassmorphism p-6 rounded-3xl text-center professional-border">
              <Database size={48} className="mx-auto mb-4" style={{ color: 'hsl(215, 20%, 25%)' }} />
              <h3 className="text-xl font-semibold mb-4">Data & AI</h3>
              <div className="space-y-3">
                {dataWebSkills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span>{skill.name}</span>
                      <span>{skill.percentage}%</span>
                    </div>
                    <div className="progress-bar h-2">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${skill.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Tools & Technologies */}
          <div className="glassmorphism p-8 rounded-3xl">
            <h3 className="text-2xl font-semibold mb-8 text-center" style={{ color: 'hsl(195, 100%, 50%)' }}>
              Tools & Technologies
            </h3>
            <div className="grid md:grid-cols-4 gap-6">
              {tools.map((tool, index) => (
                <div key={index} className="text-center group">
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform"
                    style={{
                      background: `linear-gradient(135deg, ${tool.colors[0]}, ${tool.colors[1]})`
                    }}
                  >
                    <tool.icon size={32} color="white" />
                  </div>
                  <p className="font-semibold">{tool.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
