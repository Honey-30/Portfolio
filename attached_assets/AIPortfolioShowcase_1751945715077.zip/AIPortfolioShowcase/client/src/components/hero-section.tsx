import { useEffect, useState } from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { useTypingEffect } from "@/hooks/use-typing-effect";
import { Download, ArrowDown } from "lucide-react";

export default function HeroSection() {
  const [stats, setStats] = useState({ cgpa: 0, projects: 0, certifications: 0 });
  const isVisible = useScrollAnimation("home");
  const typingText = useTypingEffect("AI/ML Engineer & Full Stack Developer", 100);

  useEffect(() => {
    if (isVisible) {
      // Animate stats counters
      const animateCounter = (target: number, setter: (value: number) => void) => {
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
          current += step;
          if (current >= target) {
            current = target;
            clearInterval(timer);
          }
          setter(current);
        }, 16);
      };

      animateCounter(8.66, (value) => setStats(prev => ({ ...prev, cgpa: value })));
      animateCounter(15, (value) => setStats(prev => ({ ...prev, projects: value })));
      animateCounter(5, (value) => setStats(prev => ({ ...prev, certifications: value })));
    }
  }, [isVisible]);

  const scrollToProjects = () => {
    const element = document.getElementById('projects');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const downloadResume = () => {
    // Create a mock resume download
    const link = document.createElement('a');
    link.href = '/api/resume/download';
    link.download = 'Honey_Nandal_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="container mx-auto px-6 text-center z-10">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h1 className="text-6xl md:text-8xl font-bold mb-4 gradient-text">
            HONEY NANDAL
          </h1>
          <div className="text-2xl md:text-3xl font-mono mb-8">
            <span className="typing-effect">
              {typingText}
            </span>
          </div>
          <p className="text-xl md:text-2xl mb-12 max-w-4xl mx-auto leading-relaxed">
            Crafting intelligent solutions with cutting-edge AI/ML technologies. 
            Specialized in{" "}
            <span style={{ color: 'hsl(210, 50%, 60%)' }}>Deep Learning</span>,{" "}
            <span style={{ color: 'hsl(220, 15%, 55%)' }}>Natural Language Processing</span>, and{" "}
            <span style={{ color: 'hsl(215, 20%, 25%)' }}>Computer Vision</span>.
          </p>
          <div className="flex flex-col md:flex-row gap-6 justify-center">
            <button
              onClick={scrollToProjects}
              className="liquid-button px-8 py-4 rounded-full font-semibold text-lg"
            >
              <span className="relative z-10">Explore My Work</span>
            </button>
            <button
              onClick={downloadResume}
              className="glassmorphism px-8 py-4 rounded-full font-semibold text-lg border-2 hover:bg-electric-blue hover:text-dark-navy transition-all flex items-center gap-2 justify-center"
              style={{ borderColor: 'hsl(210, 50%, 60%)' }}
            >
              <Download size={20} />
              Download Resume
            </button>
          </div>
        </div>
      </div>
      
      {/* Animated Stats */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex space-x-12">
        <div className="text-center">
          <div className="stats-counter">
            {stats.cgpa.toFixed(2)}
          </div>
          <div className="text-sm text-gray-400">CGPA</div>
        </div>
        <div className="text-center">
          <div className="stats-counter">
            {Math.floor(stats.projects)}
          </div>
          <div className="text-sm text-gray-400">Projects</div>
        </div>
        <div className="text-center">
          <div className="stats-counter">
            {Math.floor(stats.certifications)}
          </div>
          <div className="text-sm text-gray-400">Certifications</div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown size={24} className="text-electric-blue" />
      </div>
    </section>
  );
}
