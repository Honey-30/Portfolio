import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { Brain, BarChart3, Globe, ExternalLink } from "lucide-react";

export default function ProjectsSection() {
  const isVisible = useScrollAnimation("projects");

  const projects = [
    {
      title: "Neural Network Classifier",
      description: "Advanced deep learning model for image classification with 95% accuracy",
      icon: Brain,
      color: "hsl(210, 50%, 60%)",
      secondaryColor: "hsl(220, 15%, 55%)",
      code: `# Neural Network Implementation
import tensorflow as tf
model = tf.keras.Sequential([
    Dense(128, activation='relu'),
    Dropout(0.2),
])`,
      tags: ["Python", "TensorFlow"],
      tagColors: ["hsl(195, 100%, 50%)", "hsl(270, 100%, 50%)"]
    },
    {
      title: "Data Analytics Dashboard",
      description: "Interactive Tableau dashboard for business intelligence and insights",
      icon: BarChart3,
      color: "hsl(215, 20%, 25%)",
      secondaryColor: "hsl(210, 50%, 60%)",
      code: `# Data Analysis Pipeline
import pandas as pd
df = pd.read_csv('data.csv')
insights = analyze_trends(df)
visualize_data(insights)`,
      tags: ["Tableau", "Excel"],
      tagColors: ["hsl(120, 100%, 50%)", "hsl(195, 100%, 50%)"]
    },
    {
      title: "Web Application",
      description: "Full-stack web application with optimized UI/UX reducing bounce rate by 20%",
      icon: Globe,
      color: "hsl(220, 10%, 70%)",
      secondaryColor: "hsl(215, 15%, 75%)",
      code: `// React Component
const App = () => {
  return (
    <div className="app">
      <Header />
    </div>
  );
};`,
      tags: ["React", "CSS"],
      tagColors: ["hsl(328, 100%, 54%)", "hsl(51, 100%, 50%)"]
    }
  ];

  return (
    <section id="projects" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">
            Featured Projects
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="project-card glassmorphism p-6 rounded-3xl professional-border">
                <div className="text-center mb-6">
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{
                      background: `linear-gradient(135deg, ${project.color}, ${project.secondaryColor})`
                    }}
                  >
                    <project.icon size={32} color="white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                </div>
                
                <div className="code-block p-4 mb-4 font-mono text-sm">
                  {project.code.split('\n').map((line, lineIndex) => (
                    <div key={lineIndex} className={`${
                      line.includes('#') || line.includes('//') ? 'text-green-400' :
                      line.includes('import') || line.includes('const') ? 'text-white' :
                      line.includes('=') ? 'text-blue-400' :
                      line.includes('(') || line.includes(')') ? 'text-purple-400' :
                      'text-pink-400'
                    }`}>
                      {line}
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="px-2 py-1 text-xs rounded"
                        style={{
                          backgroundColor: `${project.tagColors[tagIndex]}20`,
                          color: project.tagColors[tagIndex]
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <button className="hover:text-white transition-colors" style={{ color: 'hsl(195, 100%, 50%)' }}>
                    <ExternalLink size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
