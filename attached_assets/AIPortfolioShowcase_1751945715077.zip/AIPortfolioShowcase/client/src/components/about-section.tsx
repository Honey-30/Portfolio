import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { Brain, Rocket, Users } from "lucide-react";

export default function AboutSection() {
  const isVisible = useScrollAnimation("about");

  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">
            About Me
          </h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="glassmorphism p-8 rounded-3xl professional-border">
              <h3 className="text-2xl font-semibold mb-6" style={{ color: 'hsl(210, 50%, 60%)' }}>
                The Journey
              </h3>
              <p className="text-lg leading-relaxed mb-6">
                I'm a passionate final-year Computer Science student at VIT Amravati, 
                specializing in AI/ML with a stellar 8.66 CGPA. My journey in technology 
                began with curiosity and has evolved into a deep expertise in artificial 
                intelligence and machine learning.
              </p>
              <p className="text-lg leading-relaxed mb-6">
                From building neural networks that achieve 95% accuracy to developing 
                machine learning models that solve real-world problems, I bring both 
                technical expertise and innovative thinking to every project.
              </p>
              <div className="flex flex-wrap gap-4">
                <span className="px-4 py-2 rounded-full border" style={{ 
                  backgroundColor: 'hsla(195, 100%, 50%, 0.2)',
                  color: 'hsl(195, 100%, 50%)',
                  borderColor: 'hsl(195, 100%, 50%)'
                }}>
                  Problem Solver
                </span>
                <span className="px-4 py-2 rounded-full border" style={{ 
                  backgroundColor: 'hsla(270, 100%, 50%, 0.2)',
                  color: 'hsl(270, 100%, 50%)',
                  borderColor: 'hsl(270, 100%, 50%)'
                }}>
                  Team Player
                </span>
                <span className="px-4 py-2 rounded-full border" style={{ 
                  backgroundColor: 'hsla(120, 100%, 50%, 0.2)',
                  color: 'hsl(120, 100%, 50%)',
                  borderColor: 'hsl(120, 100%, 50%)'
                }}>
                  Innovation Driven
                </span>
              </div>
            </div>
            
            <div className="perspective-card">
              <div className="card-inner glassmorphism rounded-3xl p-8 h-96 professional-border">
                <div className="card-front">
                  <h3 className="text-2xl font-semibold mb-6" style={{ color: 'hsl(220, 15%, 55%)' }}>
                    Core Values
                  </h3>
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <Brain size={32} style={{ color: 'hsl(210, 50%, 60%)' }} />
                      <div>
                        <h4 className="font-semibold">Continuous Learning</h4>
                        <p className="text-gray-400">Always exploring new technologies</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Rocket size={32} style={{ color: 'hsl(120, 100%, 50%)' }} />
                      <div>
                        <h4 className="font-semibold">Innovation</h4>
                        <p className="text-gray-400">Pushing boundaries of what's possible</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Users size={32} style={{ color: 'hsl(328, 100%, 54%)' }} />
                      <div>
                        <h4 className="font-semibold">Collaboration</h4>
                        <p className="text-gray-400">Building together for better solutions</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="card-back">
                  <h3 className="text-2xl font-semibold mb-6" style={{ color: 'hsl(51, 100%, 50%)' }}>
                    Fun Facts
                  </h3>
                  <div className="space-y-4">
                    <p>🎯 Reduced bounce rate by 20% in my first internship</p>
                    <p>🏆 Maintaining 8.66 CGPA while exploring cutting-edge AI</p>
                    <p>🌟 Bilingual proficiency in Hindi and English</p>
                    <p>🚀 Passionate about neural networks and deep learning</p>
                    <p>💡 Always experimenting with new frameworks</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
