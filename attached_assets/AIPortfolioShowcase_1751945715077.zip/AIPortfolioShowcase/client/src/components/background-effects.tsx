export default function BackgroundEffects() {
  return (
    <>
      {/* Subtle Neural Network Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div 
          className="w-full h-full"
          style={{
            background: `radial-gradient(circle at 20% 20%, hsla(195, 100%, 50%, 0.03) 0%, transparent 40%),
                        radial-gradient(circle at 80% 80%, hsla(270, 100%, 50%, 0.03) 0%, transparent 40%),
                        radial-gradient(circle at 40% 60%, hsla(328, 100%, 54%, 0.02) 0%, transparent 40%)`
          }}
        />
      </div>
      
      {/* Subtle Grid Pattern */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(hsla(195, 100%, 50%, 0.3) 1px, transparent 1px),
                           linear-gradient(90deg, hsla(195, 100%, 50%, 0.3) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}
      />
      
      {/* Minimal Floating Particles */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="particle" style={{ top: '20%', left: '15%', animationDelay: '0s' }} />
        <div className="particle" style={{ top: '40%', left: '85%', animationDelay: '2s' }} />
        <div className="particle" style={{ top: '70%', left: '25%', animationDelay: '4s' }} />
        <div className="particle" style={{ top: '80%', left: '75%', animationDelay: '6s' }} />
      </div>
      
      {/* Subtle Neural Connections */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="neural-node" style={{ top: '25%', left: '20%' }} />
        <div className="neural-node" style={{ top: '45%', left: '80%' }} />
        <div className="neural-node" style={{ top: '75%', left: '30%' }} />
        <div className="neural-connection" style={{ top: '25%', left: '20%', width: '60%', transform: 'rotate(25deg)' }} />
        <div className="neural-connection" style={{ top: '45%', left: '30%', width: '50%', transform: 'rotate(-15deg)' }} />
      </div>
      
      {/* Very Subtle Background Blobs */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="morphing-blob w-96 h-96 absolute top-0 right-0 translate-x-1/3 -translate-y-1/3" />
        <div className="morphing-blob w-80 h-80 absolute bottom-0 left-0 -translate-x-1/3 translate-y-1/3" style={{ animationDelay: '3s' }} />
      </div>
    </>
  );
}
