import { useState } from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Mail, Phone, MapPin, Github, Twitter, Instagram, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const isVisible = useScrollAnimation("contact");
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
    },
    onError: (error) => {
      toast({
        title: "Error sending message",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section id="contact" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">
            Let's Connect
          </h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="glassmorphism p-8 rounded-3xl professional-border">
              <h3 className="text-2xl font-semibold mb-6" style={{ color: 'hsl(210, 50%, 60%)' }}>
                Get In Touch
              </h3>
              <p className="text-lg mb-8 text-gray-300">
                Ready to collaborate on cutting-edge AI/ML projects or discuss opportunities? 
                I'm always excited to connect with fellow innovators and tech enthusiasts.
              </p>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, hsl(210, 50%, 60%), hsl(220, 15%, 55%))'
                    }}
                  >
                    <Mail size={20} color="white" />
                  </div>
                  <div>
                    <p className="font-semibold">Email</p>
                    <p className="text-gray-400">honey11a13@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, hsl(120, 100%, 50%), hsl(195, 100%, 50%))'
                    }}
                  >
                    <Phone size={20} color="white" />
                  </div>
                  <div>
                    <p className="font-semibold">Phone</p>
                    <p className="text-gray-400">+91 8053291898</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, hsl(328, 100%, 54%), hsl(51, 100%, 50%))'
                    }}
                  >
                    <Linkedin size={20} color="white" />
                  </div>
                  <div>
                    <p className="font-semibold">LinkedIn</p>
                    <p className="text-gray-400">@honey-nandal</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, hsl(270, 100%, 50%), hsl(328, 100%, 54%))'
                    }}
                  >
                    <MapPin size={20} color="white" />
                  </div>
                  <div>
                    <p className="font-semibold">Location</p>
                    <p className="text-gray-400">Rohtak, India</p>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-4 mt-8">
                <button 
                  className="w-12 h-12 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  style={{
                    background: 'linear-gradient(135deg, hsl(195, 100%, 50%), hsl(270, 100%, 50%))'
                  }}
                >
                  <Github size={20} color="white" />
                </button>
                <button 
                  className="w-12 h-12 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  style={{
                    background: 'linear-gradient(135deg, hsl(120, 100%, 50%), hsl(195, 100%, 50%))'
                  }}
                >
                  <Twitter size={20} color="white" />
                </button>
                <button 
                  className="w-12 h-12 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  style={{
                    background: 'linear-gradient(135deg, hsl(328, 100%, 54%), hsl(51, 100%, 50%))'
                  }}
                >
                  <Instagram size={20} color="white" />
                </button>
              </div>
            </div>
            
            <div className="glassmorphism p-8 rounded-3xl professional-border">
              <h3 className="text-2xl font-semibold mb-6" style={{ color: 'hsl(270, 100%, 50%)' }}>
                Send Message
              </h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="relative">
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="bg-transparent border-2 focus:border-electric-blue transition-colors"
                    style={{ borderColor: 'hsla(195, 100%, 50%, 0.3)' }}
                  />
                </div>
                <div className="relative">
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-transparent border-2 focus:border-electric-blue transition-colors"
                    style={{ borderColor: 'hsla(195, 100%, 50%, 0.3)' }}
                  />
                </div>
                <div className="relative">
                  <Input
                    type="text"
                    name="subject"
                    placeholder="Subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    className="bg-transparent border-2 focus:border-electric-blue transition-colors"
                    style={{ borderColor: 'hsla(195, 100%, 50%, 0.3)' }}
                  />
                </div>
                <div className="relative">
                  <Textarea
                    name="message"
                    placeholder="Your Message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={4}
                    className="bg-transparent border-2 focus:border-electric-blue transition-colors resize-none"
                    style={{ borderColor: 'hsla(195, 100%, 50%, 0.3)' }}
                  />
                </div>
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="liquid-button w-full py-3 font-semibold"
                >
                  <span className="relative z-10">
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </span>
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
