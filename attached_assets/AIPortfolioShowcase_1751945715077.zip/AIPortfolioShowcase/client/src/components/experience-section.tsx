import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { GraduationCap, Briefcase, Code, Tag } from "lucide-react";
import { SiGoogle, SiOracle } from "react-icons/si";

export default function ExperienceSection() {
  const isVisible = useScrollAnimation("experience");

  const certifications = [
    { name: "Google AI for Anyone", icon: SiGoogle, color: "hsl(195, 100%, 50%)" },
    { name: "Google AI for JavaScript (TensorFlow.js)", icon: SiGoogle, color: "hsl(120, 100%, 50%)" },
    { name: "Java Programming Introduction", icon: Code, color: "hsl(270, 100%, 50%)" },
    { name: "Google Cloud Computing Foundations", icon: SiGoogle, color: "hsl(328, 100%, 54%)" },
    { name: "Oracle AI Foundation Associate", icon: SiOracle, color: "hsl(51, 100%, 50%)" },
  ];

  return (
    <section id="experience" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`section-reveal ${isVisible ? 'revealed' : ''}`}>
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">
            Experience & Education
          </h2>
          
          {/* Timeline */}
          <div className="relative">
            <div className="timeline-connection h-full top-0" style={{ height: '100%' }} />
            
            {/* Education */}
            <div className="flex items-center mb-12">
              <div className="timeline-node w-12 h-12 rounded-full flex items-center justify-center z-10">
                <GraduationCap size={24} color="white" />
              </div>
              <div className="ml-8 glassmorphism p-6 rounded-3xl flex-1 professional-border">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold" style={{ color: 'hsl(210, 50%, 60%)' }}>
                      B.Tech in Computer Science (AI/ML)
                    </h3>
                    <p className="text-gray-400">Vellore Institute of Technology, Amravati</p>
                  </div>
                  <span className="text-sm" style={{ color: 'hsl(220, 15%, 55%)' }}>2022 - 2026</span>
                </div>
                <p className="text-gray-300">
                  Currently pursuing specialization in AI/ML with 8.66 CGPA. Core subjects include 
                  Machine Learning, Deep Learning, Natural Language Processing, Data Structures, 
                  and Algorithm Design.
                </p>
                <div className="flex space-x-4 mt-4">
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(195, 100%, 50%, 0.2)',
                      color: 'hsl(195, 100%, 50%)'
                    }}
                  >
                    CGPA: 8.66
                  </span>
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(270, 100%, 50%, 0.2)',
                      color: 'hsl(270, 100%, 50%)'
                    }}
                  >
                    AI/ML Specialization
                  </span>
                </div>
              </div>
            </div>
            
            {/* Deloitte Experience */}
            <div className="flex items-center mb-12">
              <div className="timeline-node w-12 h-12 rounded-full flex items-center justify-center z-10">
                <Briefcase size={24} color="white" />
              </div>
              <div className="ml-8 glassmorphism p-6 rounded-3xl flex-1 professional-border">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold" style={{ color: 'hsl(120, 100%, 50%)' }}>
                      Data Analytics Job Simulation
                    </h3>
                    <p className="text-gray-400">Deloitte Australia</p>
                  </div>
                  <span className="text-sm" style={{ color: 'hsl(328, 100%, 54%)' }}>March 2025</span>
                </div>
                <p className="text-gray-300">
                  Completed comprehensive data analysis and forensic technology simulation. 
                  Applied advanced machine learning techniques and Python programming for 
                  data classification and business insights.
                </p>
                <div className="flex space-x-4 mt-4">
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(120, 100%, 50%, 0.2)',
                      color: 'hsl(120, 100%, 50%)'
                    }}
                  >
                    Python
                  </span>
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(328, 100%, 54%, 0.2)',
                      color: 'hsl(328, 100%, 54%)'
                    }}
                  >
                    Machine Learning
                  </span>
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(51, 100%, 50%, 0.2)',
                      color: 'hsl(51, 100%, 50%)'
                    }}
                  >
                    Data Analysis
                  </span>
                </div>
              </div>
            </div>
            
            {/* Octanet Experience */}
            <div className="flex items-center mb-12">
              <div className="timeline-node w-12 h-12 rounded-full flex items-center justify-center z-10">
                <Code size={24} color="white" />
              </div>
              <div className="ml-8 glassmorphism p-6 rounded-3xl flex-1 professional-border">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold" style={{ color: 'hsl(270, 100%, 50%)' }}>
                      Intern Web Developer
                    </h3>
                    <p className="text-gray-400">Octanet Services, Bengaluru</p>
                  </div>
                  <span className="text-sm" style={{ color: 'hsl(195, 100%, 50%)' }}>July - August 2024</span>
                </div>
                <p className="text-gray-300">
                  Collaborated with UX/UI teams to optimize user interfaces, achieving a 
                  20% reduction in bounce rate and significant improvement in user satisfaction. 
                  Participated in workshops and explored new technologies.
                </p>
                <div className="flex space-x-4 mt-4">
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(270, 100%, 50%, 0.2)',
                      color: 'hsl(270, 100%, 50%)'
                    }}
                  >
                    UI/UX Optimization
                  </span>
                  <span 
                    className="px-3 py-1 text-sm rounded"
                    style={{
                      backgroundColor: 'hsla(195, 100%, 50%, 0.2)',
                      color: 'hsl(195, 100%, 50%)'
                    }}
                  >
                    20% Bounce Rate ↓
                  </span>
                </div>
              </div>
            </div>
            
            {/* Certifications */}
            <div className="flex items-center">
              <div className="timeline-node w-12 h-12 rounded-full flex items-center justify-center z-10">
                <Tag size={24} color="white" />
              </div>
              <div className="ml-8 glassmorphism p-6 rounded-3xl flex-1 professional-border">
                <h3 className="text-xl font-semibold mb-4" style={{ color: 'hsl(51, 100%, 50%)' }}>
                  Certifications
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {certifications.map((cert, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <cert.icon size={20} style={{ color: cert.color }} />
                      <span>{cert.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
