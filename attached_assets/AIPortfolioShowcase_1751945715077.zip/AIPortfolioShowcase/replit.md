# Honey Nandal AI/ML Portfolio

## Overview

This is a modern, full-stack portfolio website for an AI/ML student featuring a React frontend with TypeScript, Express backend, and PostgreSQL database. The application showcases professional experience, skills, projects, and provides a contact form system with advanced visual effects and animations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom AI/ML themed dark mode design
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: Built-in memory storage for development
- **API Design**: RESTful endpoints for contact form and data retrieval

### Key Design Decisions
- **Monorepo Structure**: Shared schema and types between frontend and backend
- **TypeScript First**: Full type safety across the entire application
- **Component-Based Architecture**: Modular, reusable UI components
- **Responsive Design**: Mobile-first approach with advanced animations
- **Performance Optimization**: Lazy loading, code splitting, and optimized assets

## Key Components

### Frontend Components
1. **Portfolio Sections**: Hero, About, Skills, Projects, Experience, Contact
2. **Interactive Elements**: Animated cursor, floating particles, neural network backgrounds
3. **Form Handling**: Contact form with validation and submission
4. **Navigation**: Smooth scrolling navigation with section awareness
5. **Animations**: Scroll-triggered animations, typing effects, morphing backgrounds

### Backend Services
1. **Contact API**: Handles form submissions with validation
2. **Storage Layer**: Abstracted storage interface supporting both memory and database
3. **Error Handling**: Comprehensive error handling with proper HTTP status codes
4. **Request Logging**: Detailed API request logging for debugging

### Database Schema
- **Users Table**: Basic user authentication structure (prepared for future use)
- **Contacts Table**: Stores contact form submissions with timestamps
- **Validation**: Zod schema validation for all database operations

## Data Flow

1. **Client Request**: User interacts with portfolio sections or submits contact form
2. **Form Validation**: Client-side validation using React Hook Form and Zod
3. **API Communication**: TanStack Query handles API requests with error handling
4. **Server Processing**: Express routes process requests with validation
5. **Database Operations**: Drizzle ORM handles database interactions
6. **Response Handling**: Structured JSON responses with proper error codes
7. **UI Updates**: React Query updates UI state and shows success/error messages

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **Database**: Drizzle ORM, Neon Database serverless driver
- **UI Libraries**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Validation**: Zod for schema validation
- **Date Handling**: date-fns for date manipulation

### Development Dependencies
- **Build Tools**: Vite, ESBuild, TypeScript compiler
- **Development**: tsx for TypeScript execution, PostCSS for CSS processing
- **Replit Integration**: Replit-specific plugins for development environment

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR (Hot Module Replacement)
- **Database**: Neon Database serverless for development and production
- **Environment Variables**: DATABASE_URL for database connection

### Production Build
- **Frontend**: Vite builds optimized React application to `dist/public`
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Static Assets**: Served through Express static middleware
- **Database Migrations**: Drizzle Kit handles schema migrations

### Build Process
1. **Type Checking**: TypeScript compilation validation
2. **Frontend Build**: Vite creates optimized production bundle
3. **Backend Build**: ESBuild creates server bundle with external dependencies
4. **Database Setup**: Drizzle push applies schema changes
5. **Production Start**: Node.js serves the built application

## Changelog

Changelog:
- July 08, 2025: Initial setup
- July 08, 2025: Added PostgreSQL database integration with Drizzle ORM
- July 08, 2025: Updated color palette to professional formal theme (steel blue, slate gray, charcoal) for business-ready presentation

## User Preferences

Preferred communication style: Simple, everyday language.